﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=OKI\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
